from .decoder import Decoder

name = "urldecoder"
